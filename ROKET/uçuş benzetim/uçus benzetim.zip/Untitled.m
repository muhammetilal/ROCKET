clc;
clear;
clear all;
close all;
ax = axes('XLim',[-4 4],'YLim',[-4 4],'ZLim',[-4 4]);
view(3); grid on; axis equal;
 %axis off;
% Create objects to group
[cylx,cyly,cylz]=cylinder(.4);
[conx,cony,conz]=cylinder([1,0]);
[mx,my,mz]=cylinder([0,0.1]);
[x,y,z]=sphere(50);
h(1)=surface(x,y,z-1);
h(2)=surface(cylx,cyly,cylz*2+1); %orta g�vde
h(3)=surface(conx/2-0.01,cony/2-0.01,conz+3); %ba� k�s�m�
h(4)=surface(my/2,mx/4+0.4,mz/1.5+0.5,'FaceColor','red');
h(5)=surface(my/2,mx/4-0.4,mz/1.5+0.5,'FaceColor','red');
h(6)=surface(my/2+0.4,mx/4,mz/1.5+0.5,'FaceColor','red');
h(7)=surface(my/2-0.4,mx/4,mz/1.5+0.5,'FaceColor','red');
set(h(2:7),'Clipping','off');
t = hgtransform('Parent',ax);
set(h(2:7),'Parent',t);

%% GPS

a=37.0866;

b=29.35225;
%transmitter
tx = txsite('Name','MathWorks Apple Hill',...
       'Latitude',a, ...
       'Longitude',b);
  % show(tx);
   
 %receiver
   rx = rxsite('Name','MathWorks Lakeside', ...
       'Latitude',37.3021, ...
       'Longitude',29.3764);
  
   %distance
   dm = distance(tx,rx); % Unit: m
   dkm = dm / 1000; %unit:km
   azFromEast = angle(tx,rx); % Unit: degrees counter-clockwise from East
   azFromNorth = -azFromEast + 90; % Convert angle to clockwise from North
   
   ss = sigstrength(rx,tx);
   margin = abs(rx.ReceiverSensitivity - ss); %hassassiyeti ��kararak �l�er
   %link(rx,tx)
  coverage(tx,'close-in', ...
      'SignalStrengths',-100:5:-60) %sinyl g�c�neg g�re kapsad��� alan

%% u�u� benzetim
clc;
clear;
clear all;
g=9.801; %yer�ekimi ivmesi
%zaman aral�� 0.01 saniye olmas� laz�m
%il konum [0 0 0];
x_ilk=0; %ilk konum
z_ilk=0;%ilk konum
v=100;
a=70;% u�u�i yola a��s�;
m=2.5;%a��rl�k 
y=3000; %maksimum irtifa

%%yukar�ya ��k��

t_ucus=(2*v*sind(a))/g;
t_cikis=t_ucus/2;
time=0:0.01:t_ucus;
vx=v*cosd(a);
vz=v*sind(a)-g*time;
max_irtifa=(v*sind(a)^2)/(2*g);
max_uzaklik=v*cosd(a).*t_ucus;
x_konum=vx.*time;
z_konum=(v*sind(a).*time) - (1/2).*g.*(time.^2);
% plot(x_konum,z_konum);

[maxx,idx] = max(x_konum);
[maxz,idz] = max(z_konum);
plot(x_konum,z_konum,x_konum(idx),z_konum(idx),'pr');
legend(sprintf('Max �rtifa = %0.3f',maxz),sprintf('Maximum Uzakl�k = %0.3f',maxx));
axis([xlim min(x_konum) max(x_konum)+1]);
trxt=('Max Uzakl�k');
txt=('Maximum �rtifa \uparrow');
 text(x_konum(length(time)),z_konum(length(time)),trxt,'VerticalAlignment','bottom');
 text(x_konum(idz),maxz,txt,'HorizontalAlignment','right');
 %% Simulation
 clc;
clear;
clear all;
g=9.801; %yer�ekimi ivmesi
%zaman aral�� 0.01 saniye olmas� laz�m
%il konum [0 0 0];
x_ilk=0; %ilk konum
z_ilk=0;%ilk konum
v=100;
a=70;% u�u�i yola a��s�;
m=2.5;%a��rl�k 
t_ucus=(2*v*sind(a))/g;
t_cikis=t_ucus/2;
for t=0:0.1:t_ucus
time=0:0.01:t;
vx=v*cosd(a);
% max_irtifa=(v*sind(a)^2)/(2*g);
% max_uzaklik=v*cosd(a).*t_ucus;
x_konum=vx.*time;
z_konum=(v*sind(a).*time) - (1/2).*g.*(time.^2);
% plot(x_konum,z_konum);
[maxx,idx] = max(x_konum);
[maxz,idz] = max(z_konum);
plot(x_konum,z_konum,x_konum(idx),z_konum(idx),'pr');
legend(sprintf('Max �rtifa = %0.3f',maxz),sprintf('Maximum Uzakl�k = %0.3f',maxx));
% axis([xlim min(x_konum) max(x_konum)+1]);
trxt=('Max Uzakl�k');
txt=('Maximum �rtifa \uparrow');
 text(x_konum(idx),z_konum(idx),trxt,'VerticalAlignment','bottom');
 text(x_konum(idz),maxz,txt,'HorizontalAlignment','right');
 drawnow;
end
