# MPU-6050 MATLAB Toolbox
Calculation of Orientation from MPU-6050 Accelerometer + Gyro and Data Visualization with Matlab

![ScreenShot](https://raw.githubusercontent.com/SayanSeth/MPU-6050-Arduino-and-Matlab/master/pic.png)
